﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CycleAnimator : MonoBehaviour
{
    public bool freeze;
    public bool terminateUponFinish;
    public string directory; // any folders between the source animation folder and the GameFiles folder. Stays the same as long as the object's identity remains the same, unlike animationFolder.
    public string animationFolder; // the specific folder in which the images are contained, subject to change depending on sprite's animation state. For convenience, this is seperate from directory.
    public int fps;
    public int frame;
    public int frameClock;
    public GameObject syncWith;
    private UnityEngine.Object[] folder;



    void Start()
    {
        frame = 0;
        frameClock = 0;

    }

    void Update()
    {
        // my code is ugly and stupid...
        // but it works.
        folder = Resources.LoadAll("GameSprites/" + directory + "/" + animationFolder, typeof(Sprite));
        if (syncWith != null)
        {
            var sw = syncWith.GetComponent<CycleAnimator>();
            frame = sw.frame;
            fps = sw.fps;
            frameClock = sw.frameClock;
            animationFolder = sw.animationFolder;
        }
        if (freeze == false)
        {
            frameClock += fps;
            if (frameClock > 100)
            {
                frame += 1;
                frameClock = 0;
            }
            if (frame >= folder.Length)
            {
                frame = 0;
                if (terminateUponFinish == true)
                {
                    Destroy(gameObject);
                }
            }
        }
        //Sprite texture = Resources.Load("Gamesprites/" + directory + "/" + frames[frame], typeof(Sprite)) as Sprite;
        //Debug.Log(texture);
        Sprite texture = (Sprite)folder[frame];
        GetComponent<SpriteRenderer>().sprite = texture;
        

    }
}
