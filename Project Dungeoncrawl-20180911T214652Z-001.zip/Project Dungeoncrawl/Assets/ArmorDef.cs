﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmorDef : MonoBehaviour {

    public string itemName;
    public float protection;
    public float weight;
    public float durability;

    // Use this for initialization
    void Start () {
        var ps = transform.parent.GetComponent<PlayerScript>();
        if (ps != null)
        {
            GetComponent<CycleAnimator>().directory = deriveDirectory("Apparel");
        }
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    string deriveDirectory(string name)
    {
        return name + "/" + transform.parent.GetComponent<PlayerScript>().gender + "/" + itemName.Replace(" ", "");
    }
}
