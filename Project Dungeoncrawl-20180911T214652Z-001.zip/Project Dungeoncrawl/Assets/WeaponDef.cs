﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponDef : MonoBehaviour { // Ultimately I decided to do it this way rather than creating abstract classes, don't judge me

    public List<Transform> MeleeWeaponStates;
    public List<string> wieldTypes;
    public string itemName;
    public float damage;
    public float weight;
    public float durability;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
