﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {
    
    public GameObject Weapon;
    public GameObject Apparel;
    public string gender;
    public string actionState;

	// Use this for initialization
	void Start () {
        GetComponent<CycleAnimator>().directory = deriveDirectory("CharacterAnimation");
	}
	
	// Update is called once per frame
	void Update () {
        CycleAnimator anim = GetComponent<CycleAnimator>();
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        Weapon.SetActive(anim.animationFolder == "Slash");
        if (anim.animationFolder == "Slash") {
            var mw = Weapon.GetComponent<WeaponDef>().MeleeWeaponStates[anim.frame];
            Weapon.transform.localPosition = mw.localPosition;
            Weapon.transform.localEulerAngles = mw.localEulerAngles;
            sr.sortingOrder = (int)mw.localScale.x;
        }
        anim.animationFolder = actionState;
        
    }
    string deriveDirectory (string name)
    {
            return name + "/" + gender;
    }
}
